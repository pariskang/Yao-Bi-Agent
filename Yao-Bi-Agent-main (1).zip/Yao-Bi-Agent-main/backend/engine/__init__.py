"""Rule engine utilities."""
